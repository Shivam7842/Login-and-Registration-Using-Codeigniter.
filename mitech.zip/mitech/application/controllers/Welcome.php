<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_model');
		$this->load->helper('url','form','base_url');
    	$this->load->library('form_validation');
		$this->load->database();
	}

	//login
	public function index()
	{
		$this->load->view('welcome_message');
	}

	//login system
	public function auth() {

		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'username', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		if ($this->form_validation->run()) {
		
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$this->load->model('Admin_model');
		$admin = $this->Admin_model->get_admin_by_username_password($username, $password);

		if ($admin) {

		$this->session->set_userdata('logged_in', $admin);
		redirect('admin/dashboard');
		} else {
		$this->session->set_flashdata('error_message', 'Incorrect username or password');
		redirect('admin/signup');
		}
		
		}
		else {
			$this->index();
		}
	}

	// admin Dashboard
	public function admin_dashboard()
	{
		$this->load->model('Admin_model');
		$data['admins'] = $this->Admin_model->get_all_admin();
		$this->load->view('admin/dashboard', $data);
	}
	

	// admin edit 
	public function edit($id){
		$this->load->model('Admin_model');
		$data['admin']=$this->Admin_model->edit_by_admin($id);
		$this->load->view('admin/edit',$data);
		

	}

	//admin update

	public function update($id){
		$this->Admin_model->update_by_admin($id);
		$this->admin_dashboard();

		
	}
	//admin delete
	public function delete($id){
		$this->load->model('Admin_model');
		$data['admin']=$this->Admin_model->delete_by_admin($id);
		$this->admin_dashboard();	

	}

	
	//	open registration page

	public function admin_signup(){
		$this->load->view('admin/signup');
	}
	//signup
	public function signup() {
		$this->load->library('form_validation');
		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('mobile', 'mobile', 'required');
		$this->form_validation->set_rules('email', 'email', 'required|valid_email');
		$this->form_validation->set_rules('dob', 'dob', 'required');
		$this->form_validation->set_rules('address', 'address', 'required');
		$this->form_validation->set_rules('username', 'username', 'required');
    	$this->form_validation->set_rules('password', 'password', 'required');
    	$this->form_validation->set_rules('confirm_password', 'confirm_password', 'required|matches[password]');
		if ($this->form_validation->run() === false) {
			// Validation failed, show registration form with errors
			$this->load->view('register');
		  } else {

        $data = array(
            
            'name' => $this->input->post('name'),
            'mobile' => $this->input->post('mobile'),
            'email' => $this->input->post('email'),
			'dob' => $this->input->post('dob'),
			'address' => $this->input->post('address'),
            'username' => $this->input->post('username'),
            'password' => $this->input->post('password'),
            'date' => date("Y-m-d H:i:s")
        );

        $result = $this->Admin_model->insert($data);

        if ($result) {
            $this->session->set_flashdata('success_msg', 'added successfully.');
        } else {
            $this->session->set_flashdata('error_msg', 'Failed to add ');
        }
        redirect(base_url('welcome_message'));
    }
}

	
	
}
?>