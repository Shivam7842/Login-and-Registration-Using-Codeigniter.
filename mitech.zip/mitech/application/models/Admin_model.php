<?php
class Admin_model extends CI_Model {
  public function get_admin_by_username_password($username, $password) {
    $query = $this->db->get_where('admin', array('username' => $username, 'password' => $password));
    return $query->row();
  }

  public function insert($data) {
    return $this->db->insert('admin', $data);
  }

  public function get_all_admin() {
    return $this->db->get('admin')->result();
  }

  public function edit_by_admin($id){
    $this->db->select('*');
    $this->db->where('id',$id);
    $query = $this->db->get('admin');
    return $query->row_array();

}

  public function update_by_admin($id){

    $data = array(
              'name' => $this->input->post('name'),
              'mobile' => $this->input->post('mobile'),
              'email' => $this->input->post('email'),
              'dob' => $this->input->post('dob'),
              'address' => $this->input->post('address'),
              'username' => $this->input->post('username')
              
            ); 
    $this->db->where('id', $id);
		$this->db->update('admin', $data);


  }

  public function delete_by_admin($id) {
    $this->db->where('id', $id);
    $this->db->delete('admin');
  }

  
}
?>