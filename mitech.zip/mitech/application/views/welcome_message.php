<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>


</head>
<body>

<div id="container">
<div class="row">
	<div class="col-lg">
		<h1>Welcome to Login page!</h1>

	<div id="body">
	<?php echo $this->session->flashdata('error_message'); ?>
		<form action="<?php echo site_url('Welcome/auth'); ?>" method="post">
		<div class="form-group">
			<br>
			<label for="username">Username</label>
			<input type="text" class="form-control" id="username" name="username">
		</div><br>
		<div class="form-group">
			<label for="password">Password</label>
			<input type="password" class="form-control" id="password" name="password">
		</div><br>
  		<button type="submit" name="submit" class="btn btn-primary ">Submit</button>
		<br>
		<br>
		  <div class="text-center">
            <p>Not a member? <?php echo anchor("Welcome/admin_signup","REGISTER");?></p>
            <p>or sign up with:</p>    
			                
        </div>
		</form><br>	
		
</div>
	
</div>

</body>
</html>

<link rel="stylesheet" href='<?php echo base_url("assest/css/signup.css");?>'/>
