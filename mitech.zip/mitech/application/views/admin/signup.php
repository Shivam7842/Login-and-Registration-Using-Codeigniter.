<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
    <title> Sign Up</title>
</head>
<body>
<p>  
    <a href="<?php echo base_url('welcome_message')?>" class="btn btn-success btn-sm" style="position:absolute;right: 20px;">BACK</a>
</p><br><br>

    <h1> Sign Up</h1>
    <?php if ($this->session->flashdata('success_msg')) { ?>
        <div class="alert alert-success">
            <?php echo $this->session->flashdata('success_msg'); ?>
        </div>
    <?php } ?>

    <?php if ($this->session->flashdata('error_msg')) { ?>
        <div class="alert alert-danger">
            <?php echo $this->session->flashdata('error_msg'); ?>
        </div>
    <?php } ?>

    

    
    <form action="<?php echo site_url('Welcome/signup'); ?>" method="post">
       
        <div>
            <label>Name:</label>
            <input type="text" name="name"  value="<?php echo set_value('name'); ?>" required>
        </div>
        <br>
        
        <div>
            <label>Mobile:</label>
            <input type="text" name="mobile" value="<?php echo set_value('mobile'); ?>" required>
        </div>
        <br>
        <div>
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo set_value('email'); ?>" required>
        </div>
        <br>

        <div>
            <label>Address:</label>
            <input type="text" name="address" value="<?php echo set_value('address'); ?>" required>
        </div>
        <br>
        <div>
            <label>Date of Birth:</label>
            <input type="date" name="dob" value="<?php echo set_value('dob'); ?>" required>
        </div>
        <br>
        
        
        <div>
            <label>Username:</label>
            <input type="text" name="username" value="<?php echo set_value('username'); ?>" required>
        </div>
        <br>
        <div>
            <label>Password:</label>
            <input type="password" name="password" value="<?php echo set_value('password'); ?>" required>
        </div>
        <br>
        <div>
            <label>Confirm Password:</label>
            <input type="password" name="confirm_password" value="<?php echo set_value('confirm_password'); ?>" required>
        </div>
        <br>
        <div>
            <input type="submit" value="Sign Up">
        </div>
        <br>
    </form>
</body>
</html>

<link rel="stylesheet" href='<?php echo base_url("assest/css/signup.css");?>'/>



            

   