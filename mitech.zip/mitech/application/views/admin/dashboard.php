<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Admin Dashboard</title>
</head>
<body>
<div id="container">

<p>  
    <a href="<?php echo base_url('welcome_message')?>" class="btn btn-success btn-sm" style="position:absolute;right: 20px;">BACK</a>
</p><br><br>
<div class="row">
	<div class="col-lg-">
	
<div class="table-responsive">
	
	
<table class="table">

    <thead>
    <tr>
        <th>S.No</th>
        <th>Name</th>
        <th>Mobile</th>
        <th>Email</th>
        <th>dob</th>
        <th>Address</th>
        <th>Username</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
        <?php $sno = 1; foreach($admins as $admin): ?>                    
        <tr> 
            <td><?php echo $sno++; ?></td>
            <td><?php echo $admin->name; ?></td>
            <td><?php echo $admin->mobile; ?></td>
            <td><?php echo $admin->email; ?></td>
            <td><?php echo $admin->dob; ?></td>
            <td><?php echo $admin->address; ?></td>
            <td><?php echo $admin->username; ?></td>
            <td>
                <a href="<?php echo base_url('Welcome/edit/'.$admin->id)?>" class="btn btn-success btn-sm">EDIT</a>
                <a href="<?php echo base_url('Welcome/delete/'.$admin->id)?>" class="btn btn-danger btn-sm">DELETE</a>
            </td>
        </tr>        
        <?php endforeach; ?>
        
    </tbody>
    
    
    
</table>

</div>
	
</div>

</body>
</html>

<link rel="stylesheet" href='<?php echo base_url("assest/css/bootstrap.min.css");?>'/>
<script src="<?php echo base_url("assest/js/jquery-3.1.0.js");?>"></script>
<script src="<?php echo base_url("assest/js/bootstrap.js");?>"></script>
	
